Run RobokitsAVRUSBProgSetup.exe for standalone programmer application. It can read/write hex files and set fusebits and lock bits.

If you are using WinAVR for creating hex files you can directly program your generated files from WinAVR. You need to install a patch for that. Run RobokitsAVRUSBProgWinAVRPatch.exe and install in WinAVR folder.

For using the programmer within WinAVR you need to set 2 parameters in makefile.

AVRDUDE_PROGRAMMER = stk500v2
AVRDUDE_PORT = robokitsusbprog

If the programmer fails to run after installation you may not have .net framework installed. Run dotnetfx.exe to install that.

The programmer has 6 pin .1" pitch female connector. Pinouts are as below

Pin1 Green  : MOSI
Pin2 Yellow : MISO
Pin3 Orange : SCK
Pin4 Red    : RESET
Pin5 Brown  : VCC
Pin6 Black  : GND

For linux you need to use avrdude for programming. You also need to patch AVRDude first. Use avrdude-5.5-1.i386.rpm for that. This RPM is tested on Redhat, Fedora and Ubuntu builds.
